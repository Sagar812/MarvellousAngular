import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compfirst',
  templateUrl: './compfirst.component.html',
  styleUrls: ['./compfirst.component.css']
})
export class CompfirstComponent{


}
