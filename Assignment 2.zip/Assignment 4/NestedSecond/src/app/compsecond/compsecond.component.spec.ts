import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompsecondComponent } from './compsecond.component';

describe('CompsecondComponent', () => {
  let component: CompsecondComponent;
  let fixture: ComponentFixture<CompsecondComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompsecondComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompsecondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
