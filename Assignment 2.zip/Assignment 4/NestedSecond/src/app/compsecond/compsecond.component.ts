import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compsecond',
  templateUrl: './compsecond.component.html',
  styleUrls: ['./compsecond.component.css']
})
export class CompsecondComponent{

 
}
