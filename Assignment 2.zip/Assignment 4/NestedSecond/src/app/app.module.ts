import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CompfirstComponent } from './compfirst/compfirst.component';
import { CompsecondComponent } from './compsecond/compsecond.component';

@NgModule({
  declarations: [
    AppComponent,
    CompfirstComponent,
    CompsecondComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
